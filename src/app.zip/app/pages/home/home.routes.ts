import { Routes } from '@angular/router';
import { mainPageComponent } from './home.component';

export const homeRoutes: Routes = [

{
    path: '',
    component:mainPageComponent
    
}
];
