import { Routes } from '@angular/router';
import { ProfileComponent } from './profile.component';


export const profileRautes: Routes = [
    {
        path: '',
        component: ProfileComponent
        
    }
]