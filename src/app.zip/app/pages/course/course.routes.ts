import { Routes } from '@angular/router';
import { CoursesComponent } from './cours.component';

export const corseroutes: Routes = [
  {
    path: '',
    component: CoursesComponent
  }
];
