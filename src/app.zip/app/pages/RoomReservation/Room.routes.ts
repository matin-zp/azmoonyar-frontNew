import { Routes } from "@angular/router";
import { ReservationComponent } from "./reservation.component";




export const RoomRoutes: Routes = [
    {
        path:'',
        component:ReservationComponent
    }


]