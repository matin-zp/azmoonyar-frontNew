import { Routes } from "@angular/router";
import { SurveyListPage } from "./survey-list.page";




export const SurveyRoutes: Routes = [
    {
        path:'',
        component:SurveyListPage
    }


]