import { Routes } from '@angular/router';
import { LoginPage } from './login.component';

export const LOGIN_ROUTES: Routes = [
  {
    path: '',
    component: LoginPage
  }
];